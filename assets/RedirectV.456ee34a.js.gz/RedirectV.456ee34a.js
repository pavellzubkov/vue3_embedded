const e={beforeCreate(){const{params:e,query:r}=this.$route,{path:t}=e;this.$router.replace({path:"/"+t,query:r})},render:function(e){return e()}};export{e as default};
